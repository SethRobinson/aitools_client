using System.Diagnostics;
using System.Drawing.Imaging;

namespace RTClip
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            //this.Opacity = 0.0;
            InitializeComponent();
            Debug.Write("\n\nHello! ************\n");

            if (Clipboard.ContainsImage())
            {

                Debug.Write("\n\nSaving image\n");

                string fileName = "winclip_image.png";
                Clipboard.GetImage().Save(fileName, ImageFormat.Png);
              
            } else
            {
                Debug.Write("\n\nNo image found on clipboard\n");

            }

           
        }
    }
}