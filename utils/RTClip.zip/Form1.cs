using System.Diagnostics;
using System.Drawing.Imaging;
using System.IO;

namespace RTClip
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            //this.Opacity = 0.0;
            InitializeComponent();
            Debug.Write("\n\nHello! ************\n");

            string fileName = "winclip_image.png";

            // Prefer the raw "PNG" format if present - it preserves alpha (e.g. our own
            // "Copy to Windows clipboard" publishes it). Fall back to the flattened
            // bitmap that every other app provides.
            if (TrySavePngFormat(fileName))
            {
                Debug.Write("\n\nSaved PNG-format clipboard image\n");
            }
            else if (Clipboard.ContainsImage())
            {
                Debug.Write("\n\nSaving image\n");
                Clipboard.GetImage().Save(fileName, ImageFormat.Png);
            }
            else
            {
                Debug.Write("\n\nNo image found on clipboard\n");
            }
        }

        static bool TrySavePngFormat(string fileName)
        {
            try
            {
                if (!Clipboard.ContainsData("PNG")) return false;

                object data = Clipboard.GetData("PNG");
                byte[] bytes = data switch
                {
                    MemoryStream ms => ms.ToArray(),
                    byte[] b => b,
                    _ => null
                };

                if (bytes == null || bytes.Length == 0) return false;

                File.WriteAllBytes(fileName, bytes);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
