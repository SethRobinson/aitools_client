using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace RTClip
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            // Write mode: "RTClip.exe set <pngPath>" puts that PNG on the Windows
            // clipboard. We publish both a standard bitmap (so any app can paste) and
            // the raw PNG bytes under the "PNG" format so alpha survives a round-trip
            // back into this app's reader below.
            if (args.Length >= 2 && string.Equals(args[0], "set", StringComparison.OrdinalIgnoreCase))
            {
                SetClipboardFromPng(args[1]);
                return;
            }

            // Default (no args): read mode. Existing behavior - dump any image on the
            // clipboard to winclip_image.png in the working directory.
            var f = new Form1();
        }

        static void SetClipboardFromPng(string path)
        {
            try
            {
                if (!File.Exists(path)) return;

                byte[] pngBytes = File.ReadAllBytes(path);

                // Decode once for the standard CF_DIB bitmap. The stream must stay open
                // for the lifetime of the Image, so keep it until after SetDataObject.
                using var imgStream = new MemoryStream(pngBytes);
                var img = Image.FromStream(imgStream);

                var data = new DataObject();
                data.SetData(DataFormats.Bitmap, img);   // pasteable into any app (alpha flattened)
                var pngStream = new MemoryStream(pngBytes);
                data.SetData("PNG", false, pngStream);   // raw PNG: alpha-preserving round-trip

                // copy:true flushes the data so it persists after this process exits.
                Clipboard.SetDataObject(data, true);
            }
            catch
            {
                // Best-effort: the Unity caller reports a generic failure if the
                // clipboard wasn't updated.
            }
        }
    }
}
