using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Windows.Forms;

namespace RTClip
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            // Write mode: "RTClip.exe set <pngPath>" puts that PNG on the Windows
            // clipboard. We publish both a standard bitmap (so any app can paste) and
            // the raw PNG bytes under the "PNG" format so alpha survives a round-trip
            // back into this app's reader below.
            if (args.Length >= 2 && string.Equals(args[0], "set", StringComparison.OrdinalIgnoreCase))
            {
                SetClipboardFromPng(args[1]);
                return;
            }

            // Files mode: "RTClip.exe files [extractDir]" writes winclip_files.txt (UTF-8,
            // one absolute path per line) in the working directory when the clipboard
            // references files. Real file lists (CF_HDROP) list their existing paths; OLE
            // virtual files (FileGroupDescriptorW + FileContents, no path on disk) are
            // extracted into extractDir first. No file is written when the clipboard has
            // no file content - the Unity caller treats that as "nothing to paste".
            if (args.Length >= 1 && string.Equals(args[0], "files", StringComparison.OrdinalIgnoreCase))
            {
                DumpClipboardFileList(args.Length >= 2 ? args[1] : Directory.GetCurrentDirectory());
                return;
            }

            // Default (no args): read mode. Existing behavior - dump any image on the
            // clipboard to winclip_image.png in the working directory.
            var f = new Form1();
        }

        static void SetClipboardFromPng(string path)
        {
            try
            {
                if (!File.Exists(path)) return;

                byte[] pngBytes = File.ReadAllBytes(path);

                // Decode once for the standard CF_DIB bitmap. The stream must stay open
                // for the lifetime of the Image, so keep it until after SetDataObject.
                using var imgStream = new MemoryStream(pngBytes);
                var img = Image.FromStream(imgStream);

                var data = new DataObject();
                data.SetData(DataFormats.Bitmap, img);   // pasteable into any app (alpha flattened)
                var pngStream = new MemoryStream(pngBytes);
                data.SetData("PNG", false, pngStream);   // raw PNG: alpha-preserving round-trip

                // copy:true flushes the data so it persists after this process exits.
                Clipboard.SetDataObject(data, true);
            }
            catch
            {
                // Best-effort: the Unity caller reports a generic failure if the
                // clipboard wasn't updated.
            }
        }

        static void DumpClipboardFileList(string extractDir)
        {
            try
            {
                var paths = new List<string>();

                if (Clipboard.ContainsFileDropList())
                {
                    foreach (string? p in Clipboard.GetFileDropList())
                    {
                        if (!string.IsNullOrWhiteSpace(p) && File.Exists(p))
                            paths.Add(Path.GetFullPath(p));
                    }
                }
                else
                {
                    paths.AddRange(ExtractVirtualFiles(extractDir));
                }

                if (paths.Count > 0)
                    File.WriteAllLines("winclip_files.txt", paths, new UTF8Encoding(false));
            }
            catch
            {
                // Best-effort: no output file means "no files found" to the caller.
            }
        }

        // FILEDESCRIPTORW: DWORD flags + CLSID + SIZEL + POINTL + DWORD attrs +
        // 3x FILETIME + 2x DWORD size = 72 bytes, then WCHAR cFileName[260].
        const int FileDescriptorSize = 72 + 260 * 2;
        const int FileDescriptorNameOffset = 72;

        /// <summary>
        /// Extract OLE virtual files (FileGroupDescriptorW + FileContents) to real files
        /// in <paramref name="extractDir"/> and return their paths. This is how modern
        /// apps put "a file with no path" on the clipboard.
        /// </summary>
        static List<string> ExtractVirtualFiles(string extractDir)
        {
            var result = new List<string>();

            var dataObj = Clipboard.GetDataObject();
            if (dataObj == null || !dataObj.GetDataPresent("FileGroupDescriptorW")) return result;

            string[] names = ParseFileGroupDescriptorNames(dataObj);
            if (names.Length == 0) return result;

            Directory.CreateDirectory(extractDir);

            var comObj = dataObj as System.Runtime.InteropServices.ComTypes.IDataObject;
            for (int i = 0; i < names.Length; i++)
            {
                byte[]? bytes = null;
                if (comObj != null)
                {
                    try { bytes = GetFileContentsCom(comObj, i); }
                    catch { }
                }
                if (bytes == null && i == 0)
                {
                    // WinForms fallback (first item only - its FileContents accessor
                    // cannot address later indexes).
                    try
                    {
                        if (dataObj.GetData("FileContents", true) is MemoryStream ms)
                            bytes = ms.ToArray();
                    }
                    catch { }
                }
                if (bytes == null || bytes.Length == 0) continue;

                string name = SanitizeFileName(names[i]);
                if (string.IsNullOrWhiteSpace(name)) name = "pasted_file_" + i;
                string target = Path.Combine(extractDir, name);
                if (File.Exists(target))
                {
                    string stem = Path.GetFileNameWithoutExtension(name);
                    string ext = Path.GetExtension(name);
                    target = Path.Combine(extractDir, stem + "_" + Guid.NewGuid().ToString("N")[..8] + ext);
                }

                File.WriteAllBytes(target, bytes);
                result.Add(Path.GetFullPath(target));
            }

            return result;
        }

        static string[] ParseFileGroupDescriptorNames(System.Windows.Forms.IDataObject dataObj)
        {
            try
            {
                if (dataObj.GetData("FileGroupDescriptorW") is not MemoryStream ms) return Array.Empty<string>();
                byte[] buf = ms.ToArray();
                if (buf.Length < 4) return Array.Empty<string>();

                int count = BitConverter.ToInt32(buf, 0);
                if (count <= 0 || count > 1000) return Array.Empty<string>();

                var names = new List<string>(count);
                for (int i = 0; i < count; i++)
                {
                    int descStart = 4 + i * FileDescriptorSize;
                    if (descStart + FileDescriptorSize > buf.Length) break;
                    string name = Encoding.Unicode.GetString(buf, descStart + FileDescriptorNameOffset, 260 * 2);
                    int nul = name.IndexOf('\0');
                    if (nul >= 0) name = name[..nul];
                    names.Add(name);
                }
                return names.ToArray();
            }
            catch
            {
                return Array.Empty<string>();
            }
        }

        [DllImport("ole32.dll")]
        static extern void ReleaseStgMedium(ref STGMEDIUM pmedium);
        [DllImport("kernel32.dll")]
        static extern IntPtr GlobalLock(IntPtr hMem);
        [DllImport("kernel32.dll")]
        static extern bool GlobalUnlock(IntPtr hMem);
        [DllImport("kernel32.dll")]
        static extern IntPtr GlobalSize(IntPtr hMem);

        /// <summary>Read the FileContents stream for one descriptor index via raw OLE.</summary>
        static byte[]? GetFileContentsCom(System.Runtime.InteropServices.ComTypes.IDataObject comObj, int index)
        {
            var format = new FORMATETC
            {
                cfFormat = unchecked((short)DataFormats.GetFormat("FileContents").Id),
                dwAspect = DVASPECT.DVASPECT_CONTENT,
                lindex = index,
                ptd = IntPtr.Zero,
                tymed = TYMED.TYMED_ISTREAM | TYMED.TYMED_HGLOBAL
            };

            comObj.GetData(ref format, out STGMEDIUM medium);
            try
            {
                if (medium.tymed == TYMED.TYMED_ISTREAM && medium.unionmember != IntPtr.Zero)
                {
                    var stream = (IStream)Marshal.GetTypedObjectForIUnknown(medium.unionmember, typeof(IStream));
                    try
                    {
                        stream.Stat(out System.Runtime.InteropServices.ComTypes.STATSTG stat, 1 /*STATFLAG_NONAME*/);
                        long size = stat.cbSize;
                        if (size <= 0 || size > int.MaxValue) return null;

                        var bytes = new byte[size];
                        IntPtr bytesReadPtr = Marshal.AllocHGlobal(sizeof(int));
                        try
                        {
                            int offset = 0;
                            while (offset < bytes.Length)
                            {
                                byte[] chunk = new byte[Math.Min(1 << 20, bytes.Length - offset)];
                                stream.Read(chunk, chunk.Length, bytesReadPtr);
                                int read = Marshal.ReadInt32(bytesReadPtr);
                                if (read <= 0) break;
                                Array.Copy(chunk, 0, bytes, offset, read);
                                offset += read;
                            }
                            return offset == bytes.Length ? bytes : null;
                        }
                        finally { Marshal.FreeHGlobal(bytesReadPtr); }
                    }
                    finally { Marshal.ReleaseComObject(stream); }
                }

                if (medium.tymed == TYMED.TYMED_HGLOBAL && medium.unionmember != IntPtr.Zero)
                {
                    IntPtr ptr = GlobalLock(medium.unionmember);
                    if (ptr == IntPtr.Zero) return null;
                    try
                    {
                        long size = (long)GlobalSize(medium.unionmember);
                        if (size <= 0 || size > int.MaxValue) return null;
                        var bytes = new byte[size];
                        Marshal.Copy(ptr, bytes, 0, (int)size);
                        return bytes;
                    }
                    finally { GlobalUnlock(medium.unionmember); }
                }

                return null;
            }
            finally
            {
                ReleaseStgMedium(ref medium);
            }
        }

        static string SanitizeFileName(string s)
        {
            var invalid = Path.GetInvalidFileNameChars();
            var sb = new StringBuilder(s.Length);
            foreach (char c in s)
                sb.Append(Array.IndexOf(invalid, c) >= 0 ? '_' : c);
            return sb.ToString().Trim();
        }
    }
}
